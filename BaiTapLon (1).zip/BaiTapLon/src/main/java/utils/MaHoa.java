﻿package utils;

import org.mindrot.jbcrypt.BCrypt;

public class MaHoa {
    public static String hashPassword(String password) {
        return BCrypt.hashpw(password, BCrypt.gensalt(12)); // 12 là độ mạnh của salt
    }

    // Kiểm tra mật khẩu nhập vào với mật khẩu đã băm
    public static boolean checkPassword(String password, String hashedPassword) {
        return BCrypt.checkpw(password, hashedPassword);
    }

    public static void main(String[] args) {
    }
}
