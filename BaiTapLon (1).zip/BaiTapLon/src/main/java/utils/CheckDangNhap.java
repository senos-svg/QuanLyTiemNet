﻿package utils;

import java.util.Scanner;

public class CheckDangNhap {
    static Scanner sc = new Scanner(System.in);

    public static boolean check_chuoi(String str) {
        if (str.isEmpty() || str.contains(" ")) {
            System.out.println("chuoi co khoang trang hoac rong");
            return false;
        } else if (str.matches(".*\\s.*") || str.matches(".*[^a-zA-Z0-9@_ ].*")) {

            System.out.println("ban da nhap cac ki tu ko duoc phep nhu ( ! ,# ,$ ...)");
            return false;
        } else {
            return true;
        }
    }

    public static String[] Login() {

        String[] kq = new String[2];
        do {
            System.out.println("nhap ten tai khoan cua ban (khong co khoan trang hay ki tu dac biet)");
            kq[0] = sc.nextLine();
            System.out.println("nhap ten tai khoan cua ban (khong co khoan trang hay ki tu dac biet)");
            kq[1] = sc.nextLine();
        } while (!check_chuoi(kq[0]) || !check_chuoi(kq[1]));
        return kq;
    }

    public static void main(String[] args) {
        System.out.println(check_chuoi("@"));
        check_chuoi("@");
    }


}
