﻿package DAOS;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;

import ketnoi.DBConnection;
import model.BaoCaoViPham;
import model.DoanhThu;
import model.MayTinh;
import model.TinhTrangMay;

public class AdminDAO {
    Connection conn;

    public AdminDAO() {
        conn = DBConnection.getConnection();
    }

    public String matkhau(String tenDangNhap) {
        String sql = "SELECT MatKhau FROM QuanTri WHERE TenDangNhap = ? ";
        String i = null;
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, tenDangNhap);

            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                i = rs.getString("MatKhau");
                return i;
            }
        } catch (SQLException e) {
            System.out.println("loi");
        }
        return i;
    }

    public List<TinhTrangMay> getMayTinhTheoTinhTrang() throws SQLException {
        String sql = "SELECT * FROM BaoCaoTinhTrang";
        List<TinhTrangMay> dstinhtrang = new ArrayList<>();
        try (PreparedStatement pst = conn.prepareStatement(sql);

                ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                int maBaoCao = rs.getInt("MaBaoCao");
                int maMay = rs.getInt("MaMay");
                String trangthaimoi = rs.getString("TrangThaiMoi");
                Date ngay = rs.getDate("NgayCapNhat");
                int MaNhanVien = rs.getInt("MaNhanVien");
                String trangthai = rs.getString("TrangThai");

                dstinhtrang.add(new TinhTrangMay(maBaoCao, maMay, MaNhanVien, trangthaimoi, trangthai, ngay));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return dstinhtrang;
    }

    public List<MayTinh> getDanhSachMayTheoTinhTrang(String maTinhTrangCanTim) throws SQLException {
        String sql = "SELECT MaMay,  MaPhong, TrangThai FROM May_tinh WHERE TrangThai = ?";
        List<MayTinh> dsMay = new ArrayList<>();

        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, maTinhTrangCanTim);

            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    int maMay = rs.getInt("MaMay");

                    int maPhong = rs.getInt("MaPhong");
                    String maTinhTrang = rs.getString("TrangThai");

                    dsMay.add(new MayTinh(maMay, maPhong, maTinhTrang));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return dsMay;
    }

    public List<BaoCaoViPham> getBaoCaoViPham() throws SQLException {
        String sql = "SELECT * FROM BaoCaoViPham a , NguoiChoi b where a.MaNguoiChoi = b.MaNguoiChoi";
        List<BaoCaoViPham> baoCaoList = new ArrayList<>();
        try (PreparedStatement pst = conn.prepareStatement(sql);
                ResultSet rs = pst.executeQuery()) {
            while (rs.next() && rs.getInt(1) > 0) {
                int maBaoCao = rs.getInt("MaBaoCao");
                int maNguoiChoi = rs.getInt("MaNguoiChoi");
                String pl_vipham = rs.getString("TenDangNhap");
                String hanhViViPham = rs.getString("HanhViViPham");
                Date ngayBaoCao = rs.getDate("NgayBaoCao");
                baoCaoList.add(new BaoCaoViPham(maBaoCao, maNguoiChoi, pl_vipham, hanhViViPham, ngayBaoCao));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return baoCaoList;
    }

    public DoanhThu getDoanhThuTrongNgay() throws SQLException {
        String sql = "SELECT * FROM DoanhThu WHERE Ngay = CAST(GETDATE() AS DATE)"; // Lấy ngày hiện tại
        DoanhThu doanhthu = null;

        try (PreparedStatement pst = conn.prepareStatement(sql);
                ResultSet rs = pst.executeQuery()) {

            if (rs.next()) {
                doanhthu = new DoanhThu();
                doanhthu.setMaDoanhThu(rs.getInt("MaDoanhThu"));
                doanhthu.setTongTien(rs.getDouble("TongTien"));
                doanhthu.setNgay(rs.getDate("Ngay"));
            }
        } catch (Exception e) {
            System.out.println("doanh thu cua ban rong");
        }
        return doanhthu;
    }
}
