/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOS;

import ketnoi.DBConnection;
import model.NguoiChoi;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author HP
 */
public class NguoiChoiDAO {
    Connection conn;

    public NguoiChoiDAO() {
        conn = DBConnection.getConnection();
    }

    public String matkhau(String tenDangNhap) {
        String sql = "SELECT MatKhau FROM NguoiChoi WHERE TenDangNhap = ? ";
        String i = null;
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, tenDangNhap);

            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                i = rs.getString("MatKhau");
                return i;
            }
        } catch (SQLException e) {
            System.out.println("loi");
        }
        return i;
    }

    public NguoiChoi thongtin(String tenDangNhap, String matKhau) {
        NguoiChoi nguoichoi = null;

        String sql = "SELECT * FROM NguoiChoi WHERE TenDangNhap = ? AND MatKhau = ?";

        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, tenDangNhap);
            pst.setString(2, matKhau);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                nguoichoi = new NguoiChoi();
                nguoichoi.setMaNguoiChoi(rs.getInt("MaNguoiChoi"));
                nguoichoi.setTenDangNhap(rs.getString("TenDangNhap"));
                nguoichoi.setMatKhau(rs.getString("MatKhau"));
                nguoichoi.setSoTien(rs.getDouble("SoTien"));
                nguoichoi.setHoTen(rs.getString("HoTen"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(NguoiChoiDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return nguoichoi;

    }

    public void ThoiGianCHoi(NguoiChoi nguoichoi, int ThoiGianCHoi) {
        Double tienbd = nguoichoi.getSoTien();
        String sql = "UPDATE NguoiChoi SET SoTien = ? WHERE TenDangNhap = ?";
        if (nguoichoi.getSoTien() >= ThoiGianCHoi * 1000) {
            System.out.println("thanh toan hop le");
            try (PreparedStatement pst = conn.prepareStatement(sql)) {
                nguoichoi.setSoTien(tienbd - ThoiGianCHoi * 1000);
                pst.setDouble(1, tienbd - ThoiGianCHoi * 1000);
                pst.setString(2, nguoichoi.getTenDangNhap());
                pst.executeUpdate();
                System.out.println("Chuc ban choi su dung vui ve");
            }

            catch (Exception e) {

            }

        } else {
            System.out.println("thanh toan ko hop le do so tien ban ko du so du");
        }
    }

    public void napTien(NguoiChoi nguoichoi, double soTienNap) {
        String updateNguoiChoiSQL = "UPDATE NguoiChoi SET SoTien = ? WHERE TenDangNhap = ?";
        String insertNapTienSQL = "INSERT INTO NapTien (MaNguoiChoi, SoTienNap, ThoiGian) VALUES (?, ?, ?)";

        double soTienMoi = nguoichoi.getSoTien() + soTienNap;

        try {
            // Bắt đầu giao dịch
            conn.setAutoCommit(false);
            try (PreparedStatement stmt = conn.prepareStatement(updateNguoiChoiSQL)) {
                stmt.setDouble(1, soTienMoi);
                stmt.setString(2, nguoichoi.getTenDangNhap());
                stmt.executeUpdate();
            }
            try (PreparedStatement stmt1 = conn.prepareStatement(insertNapTienSQL)) {
                stmt1.setInt(1, nguoichoi.getMaNguoiChoi());
                stmt1.setDouble(2, soTienNap);
                stmt1.setDate(3, Date.valueOf(LocalDate.now()));
                stmt1.executeUpdate();
            }
            conn.commit();
            nguoichoi.setSoTien(soTienMoi);
            System.out.println("Nap tien thanh cong");
        } catch (SQLException e) {
            try {
                conn.rollback();
                System.out.println("Giao dich that bai");
            } catch (SQLException rollbackEx) {
                rollbackEx.printStackTrace();
            }
            e.printStackTrace();
        }
    }

    public void napTien1(NguoiChoi nguoichoi, double soTienNap) {
        Double tienbd = nguoichoi.getSoTien();
        String sql = "UPDATE NguoiChoi SET SoTien = ? WHERE TenDangNhap = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            nguoichoi.setSoTien(tienbd + soTienNap);
            stmt.setDouble(1, tienbd + soTienNap);
            stmt.setString(2, nguoichoi.getTenDangNhap());
            stmt.executeUpdate();
            System.out.println("thanh toan thanh cong");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        String sql1 = "INSERT INTO NapTien ( MaNguoiChoi, SoTienNap, ThoiGian) VALUES ( ?, ?, ?)";
        try {
            PreparedStatement stmt1 = conn.prepareStatement(sql1);
            stmt1.setInt(1, nguoichoi.getMaNguoiChoi());
            stmt1.setDouble(2, soTienNap);
            stmt1.setDate(3, Date.valueOf(LocalDate.now()));

        } catch (Exception e) {

        }

    }
    public void dangkitaikhoan(NguoiChoi nguoiChoi){
        
            String sql = "INSERT INTO nguoichoi (HoTen, TenDangNhap, MatKhau, SoTien) VALUES (?, ?, ?, ?)";
            
            try ( 
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
        
                stmt.setString(1, nguoiChoi.getHoTen());
                stmt.setString(2, nguoiChoi.getTenDangNhap());
                stmt.setString(3, nguoiChoi.getMatKhau()); // Đã mã hóa từ trước
                stmt.setInt(4, 0); // Số tiền mặc định là 0
        
                int rowsInserted = stmt.executeUpdate();
        
                if (rowsInserted > 0) {
                    System.out.println("Đăng ký thành công!");
                } else {
                    System.out.println("Đăng ký thất bại.");
                }
        
            } catch (SQLException e) {
                System.out.println("Lỗi khi đăng ký người chơi: " + e.getMessage());
            }
        
        
    
        }
    
    
    
    }
