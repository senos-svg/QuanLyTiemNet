﻿package DAOS;

import ketnoi.DBConnection;
import model.NhanVien;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class NhanVienDAO {
    Connection conn;

    public NhanVienDAO() {
        conn = DBConnection.getConnection();
    }

    public NhanVien thongtin(String tenDangNhap, String matKhau) {
        NhanVien nv = null;
        String sql = "SELECT * FROM NhanVien WHERE TenDangNhap = ? AND MatKhau = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, tenDangNhap);
            stmt.setString(2, matKhau);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    nv = new NhanVien();
                    nv.setMaNhanVien(rs.getInt("MaNhanVien"));
                    nv.setHoTen(rs.getString("HoTen"));
                    nv.setTenDangNhap(rs.getString("TenDangNhap"));
                    nv.setMatKhau(rs.getString("MatKhau"));
                    nv.setDiaChi(rs.getString("DiaChi"));
                    nv.setSoDienThoai(rs.getString("SoDienThoai"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return nv;
    }

    public String matkhau(String tenDangNhap) {
        String sql = "SELECT MatKhau FROM NhanVien WHERE TenDangNhap = ? ";
        String i = null;
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, tenDangNhap);

            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                i = rs.getString("MatKhau");
                return i;
            }
        } catch (SQLException e) {
            System.out.println("loi");
        }
        return i;
    }

    public void baoCaoTinhTrangMay(int MaPhong, int soMay, String tinhTrang, int id) throws SQLException {
        String kiemTra = "select Trangthai from May_tinh where MaPhong = ? and MaMay = ?";

        try (PreparedStatement pst = conn.prepareStatement(kiemTra)) {

            pst.setInt(1, MaPhong);
            pst.setInt(2, soMay);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    // kiểm tra xem có dòng nào ko nếu có thì gán vào biến trangthaibd
                    String trangthaibd = rs.getString("Trangthai");
                    // cập nhât dư liệu vào cơ sở dữ liệu trong bảng báo cáo
                    String sql = "INSERT INTO BaoCaoTinhTrang ( MaMay, TrangThaiMoi,MaNhanVien,TrangThai) VALUES ( ?, ?,?,?)";
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {

                        stmt.setInt(1, soMay);
                        stmt.setString(2, tinhTrang);
                        stmt.setInt(3, id);
                        stmt.setString(4, trangthaibd);
                        stmt.executeUpdate();
                        System.out.println("Bao cao tinh trang may thanh cong!");
                    } catch (SQLException e) {
                        System.out.println("ko tim thay thong tin cua ban cung cap");
                        e.printStackTrace();
                    }
                    String up = "UPDATE May_Tinh SET Trangthai = ? WHERE  MaPhong = ? and MaMay= ?  ";
                    try (PreparedStatement stms = conn.prepareStatement(up)) {
                        stms.setString(1, tinhTrang);
                        stms.setInt(2, MaPhong);
                        stms.setInt(3, soMay);
                        stms.executeUpdate();

                    } catch (SQLException e) {

                        e.printStackTrace();
                    }
                } else {
                    System.out.println("loi ko the bao cao ko the tim thay so phong hoac so may");

                }
            }
        }

    }

    public void baoCaoViPham(String tenDangNhap, String hanhVi) throws SQLException {
        String kiemtra = "select MaNguoiCHoi from NguoiChoi where TenDangNhap = ?";

        try (PreparedStatement pst = conn.prepareStatement(kiemtra)) {
            pst.setString(1, tenDangNhap);

            try (ResultSet rs = pst.executeQuery()) {

                if (rs.next() && rs.getInt(1) > 0) {
                    int id_pl = rs.getInt("MaNguoiCHoi");
                    String sql = "INSERT INTO BaoCaoViPham (MaNguoiCHoi, HanhViViPham) VALUES (?, ?)";
                    try (
                            PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setInt(1, id_pl);
                        stmt.setString(2, hanhVi);
                        stmt.executeUpdate();
                        System.out.println("Bao cao vi pham thanh cong!");
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                } else {
                    System.out.println(" khong tim thay nguoi choi de bao cao");
                }

            }

        }
    }
}
