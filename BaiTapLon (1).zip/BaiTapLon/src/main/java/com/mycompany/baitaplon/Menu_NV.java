﻿package com.mycompany.baitaplon;

import java.sql.SQLException;
import java.util.Scanner;
import DAOS.NhanVienDAO;
import model.NhanVien;
import utils.CheckDangNhap;
import utils.MaHoa;

public class Menu_NV {
    private static Scanner scanner = new Scanner(System.in);

    public static void MenuNV(NhanVienDAO nv) {
        String tenDangNhap, matKhau;
        int choice, dk = 0;
        NhanVien i = null;

        System.out.println("MOI BAN DNAG NHAP VAO TAI KHOAN CUA MINH");
        do {
            System.out.println("nhap ten dang nhap cua nguoi choi");
            tenDangNhap = scanner.nextLine();
            System.out.println("nhap mat khau cua tai khoan nguoi choi");
            matKhau = scanner.nextLine();
            dk++;
            if (dk == 3) {
                System.out.println("ban da nhap sai qua ba lan roi");
                return;
            }

        } while (!CheckDangNhap.check_chuoi(tenDangNhap) || !CheckDangNhap.check_chuoi(matKhau));
        if (MaHoa.checkPassword(matKhau, nv.matkhau(tenDangNhap))) {
            System.out.println("dang nhap thanh cong");
            i = nv.thongtin(tenDangNhap, nv.matkhau(tenDangNhap));
            do {
                System.out.println("---- XIN CHAO NHAN VIEN " + i.getHoTen() + " ----");
                System.out.println("1. Bao cao tinh trang may");
                System.out.println("2. Bao cao vi pham");
                System.out.println("3. Thoat");
                System.out.print("Lua chon: ");
                choice = scanner.nextInt();
                scanner.nextLine();
                switch (choice) {
                    case 1:
                        dk = 0;
                        int soMay = -1, x = -1, SoP = -1;

                        String tam2, tam3, tam1;
                        String[] tinhtang = { "Dang Hu Hong", "Dang Hoat Dong", "Dang Bao Tri" };
                        do {
                            System.out.print("Nhap so phong can bao cao: ");
                            tam1 = scanner.nextLine();
                            System.out.print("Nhap so may: ");
                            tam2 = scanner.nextLine();
                            System.out.print("Nhap hanh vi 1 : Dang Hu Hong - 2 Dang Hoat Dong - 3 Dang Bao Tri : ");
                            tam3 = scanner.nextLine();
                            dk++;
                            if (dk == 3) {
                                break;
                            } else {
                                try {
                                    SoP = Integer.parseInt(tam1);
                                    soMay = Integer.parseInt(tam2);
                                    x = Integer.parseInt(tam3);

                                    try {
                                        System.out.println(x);
                                        int id = i.getMaNhanVien();
                                        nv.baoCaoTinhTrangMay(SoP, soMay, tinhtang[x - 1], id);
                                    } catch (SQLException e) {
                                        System.out.println(" ban nhap thong tin ko chinh xac");
                                        e.printStackTrace();
                                    }
                                } catch (Exception e) {
                                    System.out.println("nhap thong tin so phong so may loi");
                                    x = -1;
                                }

                            }

                        } while (!CheckDangNhap.check_chuoi(tam3) || !CheckDangNhap.check_chuoi(tam2)
                                || !CheckDangNhap.check_chuoi(tam1) || x < 1 || x > 3);

                        break;
                    case 2:
                        dk = 0;
                        String name, hanhvi;

                        do {
                            System.out.print("Nhap ten tai khoan vi pham: ");
                            name = scanner.nextLine();
                            System.out.print("nhap hanh vi vi pham cua nguoi do : ");
                            hanhvi = scanner.nextLine();
                            dk++;
                            if (dk == 3) {
                                System.out.println("ban nhap thong tin sai qua nhieu lan");
                                break;
                            } else {
                                try {
                                    nv.baoCaoViPham(name, hanhvi);
                                } catch (SQLException e) {
                                    System.out.println("loi vui long kiem tra lai thong tin truoc khi xac nhan");
                                    e.printStackTrace();
                                }
                            }
                        } while (!CheckDangNhap.check_chuoi(name) || hanhvi.isEmpty());

                        break;

                }
            } while (choice != 3);
        } else {
            System.out.println("Dang nhap that bai");
        }
    }
}
