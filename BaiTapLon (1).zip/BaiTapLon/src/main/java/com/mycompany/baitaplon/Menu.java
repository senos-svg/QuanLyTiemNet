﻿package com.mycompany.baitaplon;

import DAOS.AdminDAO;
import DAOS.NguoiChoiDAO;
import DAOS.NhanVienDAO;
import java.sql.SQLException;
import java.util.Scanner;

public class Menu {

    static Scanner scanner = new Scanner(System.in);

    public static void hienThiMenu() {

        int chon;
        AdminDAO ad = new AdminDAO();
        NguoiChoiDAO pl = new NguoiChoiDAO();
        NhanVienDAO nv = new NhanVienDAO();

        do {
            System.out.println("------ He thong quan li phong net --------");
            System.out.println("------VUI LONG DANG NHAP DE SU DUNG CHUC NANG------ ");
            System.out.println("1. Nguoi choi \r\n" + //
                    "2. Nhan vien \r\n" + //
                    "3. Quan tri \r\n" + //
                    "4. Thoat ");
            System.out.print("nhap lua chon cua ban : ");
            chon = scanner.nextInt();
            switch (chon) {
                case 1:
                    Menu_PL.MenuNguoiChoi(pl);
                    break;
                case 2:
                    Menu_NV.MenuNV(nv);
                    break;
                case 3:
                    try {
                        Menu_AD.menuadmin(ad);
                    } catch (SQLException e) {
                    }
                    break;
            }
        } while (chon > 0 && chon < 4);
        System.out.println("hien gap lai ban vao lan sao");
    }
}
