﻿package com.mycompany.baitaplon;

import java.util.Scanner;
import DAOS.NguoiChoiDAO;
import model.NguoiChoi;
import utils.CheckDangNhap;
import utils.MaHoa;

public class Menu_PL {

    static Scanner scanner = new Scanner(System.in);

    public static void MenuNguoiChoi(NguoiChoiDAO pl) {
        String TenDangNhap, mk;
        int choice, dk = 0;
        System.out.println("MOI BAN DNAG NHAP VAO TAI KHOAN CUA MINH");
        do {
            System.out.println("nhap ten dang nhap cua nguoi choi");
            TenDangNhap = scanner.nextLine();
            System.out.println("nhap mat khau cua tai khoan nguoi choi");
            mk = scanner.nextLine();
            dk++;
            if (dk == 3) {
                System.out.println("ban da nhap sai qua ba lan roi");
                return;
            }

        } while (!CheckDangNhap.check_chuoi(TenDangNhap) || !CheckDangNhap.check_chuoi(mk));

        if (MaHoa.checkPassword(mk, pl.matkhau(TenDangNhap))) {
            NguoiChoi nguoichoi = pl.thongtin(TenDangNhap, pl.matkhau(TenDangNhap));
            do {
                System.out.println("----CHAO MUNG BAN DEN VOI THE GIOI GAME----");
                System.out.println("1. Nhap thoi gian muon choi");
                System.out.println("2. Kiem tra so tien con trong tai khoan");
                System.out.println("3. Nap tien vao tai khoan");
                System.out.println("4. Thoat");
                System.out.print("Lua chon: ");
                choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {
                    case 1:
                        int thoigian = 0;
                        String str;
                        do {
                            System.out.print("nhap thoi gian ban muon choi ");
                            str = scanner.nextLine().trim();
                            if (str.isEmpty()) {
                                System.out.println("so tien ko duoc rong");
                            } else {
                                try {
                                    thoigian = Integer.parseInt(str);
                                    if (thoigian < 0) {
                                        System.out.println("so tien ko the am vui long nhap lai");
                                    }
                                } catch (Exception e) {
                                    System.out.println("so tien ban nhap khong hop le");
                                }
                            }

                        } while (thoigian < 0);
                        pl.ThoiGianCHoi(nguoichoi, thoigian);
                        break;

                    case 2:
                        System.out.println("So tien con lai trong tai khoan cua ban la " + nguoichoi.getSoTien());

                        break;
                    case 3:
                        double tien = 0;
                        String tam;
                        do {
                            System.out.print("nhap so tien ban muon nap : ");
                            tam = scanner.nextLine();

                            if (CheckDangNhap.check_chuoi(tam)) {
                                try {
                                    tien = Double.parseDouble(tam);
                                    if (tien < 10000) {
                                        System.out.println("nhap lai so tien thanh toan phai lon hon 10000");
                                    }
                                } catch (Exception e) {
                                    System.out.println("loi do ban nhap so tien khong hop le (do ban nhap co ki tu)");
                                }
                            } else {
                                System.out.println("ban nhap so tien phai la so khong duoc cac gia tri kha");
                            }

                        } while (tien < 100);
                        pl.napTien(nguoichoi, tien);
                        break;
                }
            } while (choice > 0 && choice < 4);

        } else {
            System.out.println("dang nhap that bai");
        }

    }
}
