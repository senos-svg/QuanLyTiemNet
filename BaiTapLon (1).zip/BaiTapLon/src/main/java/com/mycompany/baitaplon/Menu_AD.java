﻿package com.mycompany.baitaplon;

import java.sql.SQLException;
import java.util.List;
import model.MayTinh;
import model.BaoCaoViPham;
import model.DoanhThu;
import utils.CheckDangNhap;
import utils.MaHoa;

import java.util.Scanner;
import DAOS.AdminDAO;

public class Menu_AD {
    static Scanner scanner = new Scanner(System.in);

    public static void menuadmin(AdminDAO ad) throws SQLException {
        String TenDangNhap, mk;
        int i = 0;
        do {
            System.out.println("MOI BAN DNAG NHAP VAO TAI KHOAN CUA MINH");
            System.out.println("nhap ten dang nhap cua quan li");
            TenDangNhap = scanner.nextLine();
            System.out.println("nhap mat khau cua tai khoan cua ban");
            mk = scanner.nextLine();
            i++;
            if (i == 3) {
                System.out.println("ban dang nhap va so lan cho phep");
                return;
            }
        } while (!CheckDangNhap.check_chuoi(TenDangNhap) || !CheckDangNhap.check_chuoi(mk));
        int choice;
        if (MaHoa.checkPassword(mk, ad.matkhau(TenDangNhap))) {
            do {
                System.out.println("----XIN CHAO ADMIN----");
                System.out.println("1. Tong doanh thu trong ngay");
                System.out.println("2. Xem tinh trang may");
                System.out.println("3. Xem bao cao vi pham");
                System.out.println("4. Thoat");
                System.out.print("Lua chon: ");

                choice = scanner.nextInt();
                scanner.nextLine(); // Đọc dòng trống

                switch (choice) {
                    case 1:

                        DoanhThu doanhThu = ad.getDoanhThuTrongNgay();
                        if (doanhThu == null) {
                            System.out.println("doanh thu chua co gia tri");
                        } else {
                            System.out.println("tong so tien la " + doanhThu.getTongTien());
                        }

                        break;
                    case 2:
                        String[] tinhtang = { "Dang Hu Hong", "Dang Hoat Dong", "Dang Bao Tri" };
                        int xem_Trang_thai = -1;
                        String temp;

                        do {
                            i = 0;
                            System.out.println("nhap trang thai ban muon xem ");
                            System.out.println("1 Dang Hu Hong");
                            System.out.println("2 Dang Hoat Dong");
                            System.out.println("3 Dang Bao Tri");
                            temp = scanner.nextLine();
                            if (temp.contains(" ")) {
                                System.out.println(" Loi : Khong duoc chua khoang trang");
                            } else if (temp.isEmpty()) {
                                System.out.println("Ban nhap vao chuoi rong");
                            } else {
                                try {
                                    xem_Trang_thai = Integer.parseInt(temp);
                                } catch (Exception e) {
                                    System.out.println("Loi : ban phai nhap so ");
                                    xem_Trang_thai = -1;
                                }
                            }
                            i++;
                            if (i == 3) {
                                System.out.println("ban nhap sai qua nhiu");
                                break;
                            }

                        } while (xem_Trang_thai < 0 && xem_Trang_thai > 4);
                        System.out.println("Tinh trang may ban muon xem la : " + tinhtang[xem_Trang_thai - 1]);
                        List<MayTinh> danhsachMT = ad.getDanhSachMayTheoTinhTrang(tinhtang[xem_Trang_thai - 1]);
                        if (danhsachMT.isEmpty()) {
                            System.out.println("Tinh trang ban nhap chua co may nao bi");
                            break;
                        } else {
                            System.out.println("- ".repeat(24));

                            System.out.printf("| %-8s | %-9s | %-20s |\n", "Ma may", "Ma Phong", "Trang Thai Cua May");
                            System.out.println("- ".repeat(24));
                            for (MayTinh x : danhsachMT) {
                                System.out.printf("| %-8d | %-9d | %-20s |\n",
                                        x.getMaMay(),
                                        x.getMaPhong(),
                                        x.getMaTinhTrang());
                                System.out.println("- ".repeat(24));
                            }
                        }

                        break;
                    case 3:

                        List<BaoCaoViPham> baoCaoList = ad.getBaoCaoViPham();
                        if (baoCaoList.isEmpty()) {
                            System.out.println("Chua co tinh trang vi pham nao");
                        } else {
                            for (BaoCaoViPham baoCao : baoCaoList) {
                                System.out.println("Ma Bao Cao: " + baoCao.getMaBaoCao() + ", Tai khoan bi vi pham: "
                                        + baoCao.getTenViPham() + ", Hanh Vi Vi Pham: "
                                        + baoCao.getHanhViViPham());
                            }
                        }

                        break;
                }
            } while (choice > 0 && choice < 4);
        }
else{
    System.out.println("tai khoan va mat khau cua ban khong chinh xac");
}
    }
}
