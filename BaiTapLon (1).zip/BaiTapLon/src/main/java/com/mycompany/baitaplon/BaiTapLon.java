/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.baitaplon;

/**
 *
 * @author HP
 */
public class BaiTapLon {

  public static void main(String[] args) {
    Menu.hienThiMenu();

  }
}
