﻿package model;

import java.sql.Date;
public class BaoCaoViPham {
    private int maBaoCao;
    private int maNguoiChoi;
    private String TenViPham;
    private String hanhViViPham;   
    private Date ngayBaoCao;


    public BaoCaoViPham(int maBaoCao, int maNguoiChoi,String TenViPham, String hanhViViPham,  Date ngayBaoCao) {
        this.maBaoCao = maBaoCao;
        this.maNguoiChoi = maNguoiChoi;
        this.TenViPham = TenViPham;
        this.hanhViViPham = hanhViViPham;
        this.ngayBaoCao = ngayBaoCao;
    }

    public int getMaBaoCao() {
        return maBaoCao;
    }

    public void setMaBaoCao(int maBaoCao) {
        this.maBaoCao = maBaoCao;
    }

    public int getMaNguoiChoi() {
        return maNguoiChoi;
    }

    public void setMaNguoiChoi(int maNguoiChoi) {
        this.maNguoiChoi = maNguoiChoi;
    }

    public String getHanhViViPham() {
        return hanhViViPham;
    }

    public void setHanhViViPham(String hanhViViPham) {
        this.hanhViViPham = hanhViViPham;
    }

    public String getTenViPham() {
        return TenViPham;
    }

    public void setTenViPham(String TenViPham) {
        this.TenViPham = TenViPham;
    }

    public Date getNgayBaoCao() {
        return ngayBaoCao;
    }

    public void setNgayBaoCao(Date ngayBaoCao) {
        this.ngayBaoCao = ngayBaoCao;
    }
}
