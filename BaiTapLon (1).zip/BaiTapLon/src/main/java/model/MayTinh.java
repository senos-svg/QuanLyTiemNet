﻿package model;

public class MayTinh {
    private int maMay;    
    private int maPhong;
    private String tinhtrang;

    public MayTinh(int maMay,  int maPhong, String tinhtrang) {
        this.maMay = maMay;       
        this.maPhong = maPhong;
        this.tinhtrang = tinhtrang;
    }

    // Getter and Setter
    public int getMaMay() {
        return maMay;
    }

    public void setMaMay(int maMay) {
        this.maMay = maMay;
    }



    public int getMaPhong() {
        return maPhong;
    }

    public void setMaPhong(int maPhong) {
        this.maPhong = maPhong;
    }

    public String getMaTinhTrang() {
        return tinhtrang;
    }

    public void setMaTinhTrang(String tinhtrang) {
        this.tinhtrang = tinhtrang;
    }
}
