﻿package model;

import java.sql.Date;

public class DoanhThu {
    private int maDoanhThu;
    private Date ngay;
    private double tongTien;

    public DoanhThu(int maDoanhThu, Date ngay, double tongTien) {
        this.maDoanhThu = maDoanhThu;
        this.ngay = ngay;
        this.tongTien = tongTien;
    }
    public DoanhThu(){}
    // Getter and Setter
    public int getMaDoanhThu() {
        return maDoanhThu;
    }

    public void setMaDoanhThu(int maDoanhThu) {
        this.maDoanhThu = maDoanhThu;
    }

    public Date getNgay() {
        return ngay;
    }

    public void setNgay(Date ngay) {
        this.ngay = ngay;
    }

    public double getTongTien() {
        return tongTien;
    }

    public void setTongTien(double tongTien) {
        this.tongTien = tongTien;
    }
}
