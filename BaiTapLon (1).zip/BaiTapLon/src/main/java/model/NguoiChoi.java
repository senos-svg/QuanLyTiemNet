/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author HP
 */
public class NguoiChoi {

    private String tenDangNhap;
    private String matKhau;
    private double soTien;
    private int MaNguoiChoi;
    private String HoTen;
    public NguoiChoi(){}
    public NguoiChoi(String tenDangNhap, String matKhau, double soTien, int MaNguoiChoi, String HoTen) {
        this.tenDangNhap = tenDangNhap;
        this.matKhau = matKhau;
        this.soTien = soTien;
        this.MaNguoiChoi = MaNguoiChoi;
        this.HoTen = HoTen;
    }


    public String getTenDangNhap() {
        return tenDangNhap;
    }

    public void setTenDangNhap(String tenDangNhap) {
        this.tenDangNhap = tenDangNhap;
    }

    // Getter và Setter cho matKhau
    public String getMatKhau() {
        return matKhau;
    }

    public void setMatKhau(String matKhau) {
        this.matKhau = matKhau;
    }

    // Getter và Setter cho soTien
    public double getSoTien() {
        return soTien;
    }

    public void setSoTien(double soTien) {
        this.soTien = soTien;
    }

    // Getter và Setter cho MaNguoiChoi
    public int getMaNguoiChoi() {
        return MaNguoiChoi;
    }

    public void setMaNguoiChoi(int MaNguoiChoi) {
        this.MaNguoiChoi = MaNguoiChoi;
    }

    // Getter và Setter cho soDienThoai
    public String getHoTen() {
        return HoTen;
    }

    public void setHoTen(String HoTen) {
        this.HoTen = HoTen;
    }

    public void napTien(double soTienNap) { this.soTien += soTienNap; }
    public boolean truTien(double soTienTru) {
        if (soTienTru > 0 && soTienTru <= this.soTien) {
            this.soTien -= soTienTru;
            return true;
        }
        return false;
    }
}