﻿package model;

public class TinhTrangMay {
    private int maBaoCao;
    private Integer maMay;
    private int MaNhanVien;
    private String trangThaiMoi;
    private String trangThai;
    private java.sql.Date ngayCapNhat;
    public TinhTrangMay() {
    }

    public TinhTrangMay(int maBaoCao, Integer maMay,int MaNhanVien, String trangThaiMoi, String trangThai ,java.sql.Date ngayCapNhat) {
        this.maBaoCao = maBaoCao;
        this.maMay = maMay;
        this.MaNhanVien = MaNhanVien;
        this.trangThai = trangThai;
        this.trangThaiMoi = trangThaiMoi;
        this.ngayCapNhat = ngayCapNhat;
    }


    public int getMaBaoCao() {
        return maBaoCao;
    }

    public void setMaBaoCao(int maBaoCao) {
        this.maBaoCao = maBaoCao;
    }

    public Integer getMaMay() {
        return maMay;
    }

    public void setMaNhanVien(Integer MaNhanVien) {
        this.MaNhanVien = MaNhanVien;
    }
    public Integer getMaNhanVien() {
        return MaNhanVien;
    }

    public void setMaMay(Integer maMay) {
        this.maMay = maMay;
    }
    public String gettrangThai() {
        return trangThai;
    }

    public void settrangThai(String trangThai) {
        this.trangThai = trangThai;
    }
      public String getTrangThaiMoi() {
        return trangThaiMoi;
    }

    public void setTrangThaiMoi(String trangThaiMoi) {
        this.trangThaiMoi = trangThaiMoi;
    }

    public java.sql.Date getNgayCapNhat() {
        return ngayCapNhat;
    }

    public void setNgayCapNhat(java.sql.Date ngayCapNhat) {
        this.ngayCapNhat = ngayCapNhat;
    
}}
